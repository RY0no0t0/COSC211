public class Node {

    public Node parent;
    public Node left;
    public Node right;
    public int value;

    public Node (int data) {
        parent = null;
        left = null;
        right = null;
        value = data;
    }

}