public class Node {

    // data members
    public boolean exist;
    public double tonal;
    public double resolution;
    public double prob;

    //　Constructor
    public Node () {
        exist = true;
        tonal = 0;
        resolution = 0;
        prob = 0;
    }

}