public interface Data {

    public void initialize(int i);
    public Node at (int i, int j);
    public void RemoveIn(int i);
}